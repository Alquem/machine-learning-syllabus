from utils import *
 
#parameters to build dataset

amt_val   = 200
amt_trn   = 500
N_Cls     = 1
ISZ       = 256
n_bands   = 24
size      = 3600
band_class= 2

#path to save

base_path  ='/mnt/users/catalano/'

#original mask path

mask_orig  = base_path + 'tot_y_mask_orig.npy'
valid_mask_band=base_path + 'valid_mask_band.npy'

#val and train save path:

x_val_path = base_path + 'x_val_{}_{}_{}_{}.npy'.format(N_Cls,amt_val,band_class,n_bands)
x_trn_path = base_path + 'x_trn_{}_{}_{}_{}.npy'.format(N_Cls,amt_trn,band_class,n_bands)

y_val_path = base_path + 'y_val_{}_{}_{}_{}.npy'.format(N_Cls,amt_val,band_class,n_bands)
y_trn_path = base_path + 'y_trn_{}_{}_{}_{}.npy'.format(N_Cls,amt_trn,band_class,n_bands)


#image to keep out 


#img_out_idx=13  #buildings

#img_out_idx=5   #Trees

#img_out_idx=10   #Tracks

#img_out_idx=19   #Roads 614031



def train_val_split(valid_idx):
	
	
    x_train, y_train = np.zeros((0,n_bands,ISZ,ISZ)).astype(np.float32), np.zeros((0,N_Cls,ISZ-56,ISZ-56)).astype(np.float32)

    x_val, y_val     = np.zeros((0,n_bands,ISZ,ISZ)).astype(np.float32), np.zeros((0,N_Cls,ISZ-56,ISZ-56)).astype(np.float32)
    

    for idx in tqdm(valid_idx):

        if idx==img_out_idx:
        
            continue

        print(id_list[idx])

        m = M(id_list[idx])[0]

        
        m = normalize(m)
        
        mask = np.zeros((m.shape[0], m.shape[1],N_Cls))

        mask[:,:,0]=generate_mask_for_image_and_class((m.shape[0], m.shape[1]), id_list[idx], band_class + 1)
        
        
        print(mask.shape)
        
        print("Mask's area: {}".format(np.sum(mask)/size**2))
        
        x_crops_tr,  y_crops_tr  = get_patches(m, mask,amt_trn,"Train")

        x_crops_val, y_crops_val = get_patches(m, mask,amt_val,"Val")

        
        
        if (len(x_crops_tr) and len(y_crops_tr)) != 0:
            
            x_train = np.concatenate((x_train, x_crops_tr))
            y_train = np.concatenate((y_train, y_crops_tr))

        if (len(x_crops_val) and len(y_crops_val)) != 0:
            
            x_val = np.concatenate((x_val, x_crops_val))
            y_val = np.concatenate((y_val, y_crops_val))

        
        print(x_train.shape)
        print(y_train.shape)
        
        print(x_val.shape)
        print(y_val.shape)
        
        

    

    print("x_train shape: {}".format(x_train.shape))
    print("y_train shape: {}".format(y_train.shape))
    
    print("x_val shape: {}".format(x_val.shape))
    print("y_val shape: {}".format(y_val.shape))

    
    print("Saving dataset...")
    
    np.save(x_val_path, x_val)
    np.save(y_val_path, y_val)
    np.save(x_trn_path, x_train)
    np.save(y_trn_path, y_train)



def get_patches(img, msk,amt,dataset):
	

    crop_size=28
    is2 = int(1.0 * ISZ)
    shape=img.shape[0]

    print("start_patches") 

    x,y = [], []

    tr  = [0.4, 0.01, 0.1, 0.01, 0.3, 0.3, 0.01, 0.05, 0.001, 0.005]

    

    for i in range(amt):
        
        
        if dataset=="Train":
            
            np.random.seed(i)
            rows=np.random.randint(shape-is2)

            if rows < int(shape/2):
                
                np.random.seed(i+1)
                cols=np.random.randint(int(shape)-is2)
            
            else:
                
                np.random.seed(i+2)
                cols=np.random.randint(int(shape/2)-is2)

        
        if dataset=="Val":  

            np.random.seed(i)
            cols=np.random.randint(int(shape/2),shape-is2)

            np.random.seed(i+1)
            rows=np.random.randint(int(shape/2),shape-is2)

        
        

        im = img[rows : rows + is2, cols : cols+is2]
        ms = msk[crop_size+rows : rows + is2-crop_size, crop_size+cols : cols+is2-crop_size]

                
        sm = np.sum(ms[:, :])
                
        
        
        if 1.0 * sm / 200**2 > tr[band_class]:
            
            
            
            a = im
            b = np.rot90(a)
            c = np.rot90(b)
            d = np.rot90(c)
            e = np.fliplr(a)
            f = np.flipud(a)
            
            a_msk = ms
            b_msk = np.rot90(a_msk)
            c_msk = np.rot90(b_msk)
            d_msk = np.rot90(c_msk)
            e_msk = np.fliplr(a_msk)
            f_msk = np.flipud(a_msk)
                        
            x.append(im)
            y.append(ms)
            
            x.append(b)
            y.append(b_msk)
            
            x.append(c)
            y.append(c_msk)
            
            x.append(d)
            y.append(d_msk)
            
            x.append(e)
            y.append(e_msk)
            
            x.append(f)
            y.append(f_msk)
                    

    

    if (len(x) and len(y)) != 0:
        
        
        x, y = np.transpose(x, (0, 3, 1, 2)) , np.transpose(y, (0,3,1,2))
        
        print( x.shape, y.shape, np.amax(x), np.amin(x), np.amax(y), np.amin(y))

    return x, y
	
	


if __name__ == '__main__':
	
    # print('loading mask...')
    # mask_tot=np.load(mask_orig)
    
    # print('computing area mask...')
    # area_list=np.zeros((len(id_list)))
    
    # dict_valid_idx={}

    # for  i in range(10):     
        
        # for k in tqdm(range(len(id_list))):

            # area_list[k]=np.round(np.sum(mask_tot[k,:,:,i])/len(mask_tot[k,:,:,i].flatten()),4)
            
        
        # # for i in range(len(id_list)):

            # # print("Tracks pixel's fraction in {} is:  {}".format(id_list[i],area_list[i]))
        
        # #ids_list_valid=[ id_list[i] for i in range(len(id_list)) if  area_list[i] ]
        
        # idx_list_valid=[ i for i in range(len(id_list)) if  area_list[i] ]
        # dict_valid_idx[i]=idx_list_valid
        
    # np.save(valid_mask_band,dict_valid_idx)
       
    # print(dict_valid_idx)
        # # print(mask_tot.shape)
        
        # # print("Valid ids list: {}".format(ids_list_valid))
        # # print("Valid idx list: {}".format(idx_list_valid))
    
    
    
    valid_idx_band={0: [7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19],
                    1: [0, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,18, 19, 20], 
                    2: [8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19],
                    3: [0, 1, 3, 4, 5, 6, 7, 9, 10, 11, 12,14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
                    4: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 
                    5: [4, 7, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 23],
                    6: [8, 11], 
                    7: [8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 22, 23], 
                    8: [10, 11, 12, 14, 15, 16, 17],
                    9: [8, 10, 11, 12, 13, 14, 16, 17, 18, 19]}    

    
    valid_idx=valid_idx_band[band_class]
    
    train_val_split(valid_idx)
	
    #path_images_REG_IMG='/mnt/users/catalano/registered_img/'

     

    # for i in tqdm(id_list[10:]):
        

        # img=align_two_rasters("6100_1_3")
        # imsave(path_images_REG_IMG+'reg_img_'+ "6100_1_3" +'.tif',img)
        
    # for id in tqdm(id_list):
        
        
        # img=tiff.imread(path_images_REG_IMG+'reg_img_'+ id +'.tif')
        # img_RGB = tiff.imread(os.path.join(path_images_RGB,'{}.tif'.format(id)))
        
        # img_RGB = np.rollaxis(img_RGB, 0, 3)
        # img_RGB=cv2.resize(img_RGB,(size,size))
        # img[:,:,0]=img_RGB[:,:,0]
        # imsave(path_images_REG_IMG+'reg_img_'+ id +'.tif',img)
        

    # tot_cls=10
    # len_ids_list=len(id_list)

    # mask = np.zeros((len_ids_list,size,size,tot_cls))

    # for ids in tqdm(range(len(id_list))):
        
        # m = M(id_list[ids])[0]

        # for k in range(tot_cls):

            # mask[ids,:,:,k] = generate_mask_for_image_and_class((m.shape[0], m.shape[1]),id_list[ids], k + 1)


    # np.save(mask_orig,mask)

        
