import os 
import matplotlib.pyplot as plt
from sklearn.preprocessing import minmax_scale

from model_unet import *
from model_training import *
from val_train_creator import *
from utils import percentile_cut


#path dataaset

print('loading dataset...')

x_val,y_val = np.load(x_val_path),np.load(y_val_path)
x_tr,y_tr = np.load(x_trn_path),np.load(y_trn_path)

print('dataset loaded...')

#print(x.shape)

#print(y.shape)

#params


n_figures = 40
classes=classes_tot[band_class]

#save output path


output_folder   ='./output_pred/'

name_pred_file_val='prediction_'+'model_unet_{}_{}_{}_{}_{}'.format(amt_trn,n_channels,N_Cls,bc_size,classes)
name_pred_file_tr='training_'+'model_unet_{}_{}_{}_{}_{}'.format(amt_trn,n_channels,N_Cls,bc_size,classes)

output_path_val= os.path.join(output_folder,name_pred_file_val)
output_path_tr= os.path.join(output_folder,name_pred_file_tr)

save_fig_path = './output_pred/plot_prediction/{}{}'.format(classes,'/')+ name_model


#Code


def show_prediction(x,y_true,y_pred,id,class_name,fig_path,trs=0.5):


	classes_tot = ["Buildings", "Misc. structures", "Road", "Track", "Trees", "Crops",
			   "Waterway","Standing Water", "Vehicle Large", "Vehicle Small"]

	class_dict=dict(zip(classes_tot,range(10)))
	
	#####
	class_dict[class_name]=0

	f,axx=plt.subplots(1,3,figsize=(24,24))

	axx[0].set_title("RGB Image")
	axx[1].set_title('y_true')
	axx[2].set_title('y_pred')


	axx[0].set_ylabel(class_name,rotation=90, size='large')


	im=x[id,:]

	image = np.zeros((im.shape[1], im.shape[2], 3))

	im=np.transpose(im,(1,2,0))
	
	im= percentile_cut(im,2,98)

	image[:, :, 0] = minmax_scale(im[:, :, 0] , feature_range=(0, 255), axis=0, copy=True)  # red
	image[:, :, 1] = minmax_scale(im[:, :, 1] , feature_range=(0, 255), axis=0, copy=True)  # green
	image[:, :, 2] = minmax_scale(im[:, :, 2] , feature_range=(0, 255), axis=0, copy=True)  # blue


	tiff.imshow(image,figure=f,subplot=axx[0])


	axx[1].imshow(y_true[id, class_dict[class_name] , :, :])

	mask=y_pred[id,class_dict[class_name],:,:]>trs
	
	y_pred[id,class_dict[class_name],mask]=1
	
	axx[2].imshow(mask,cmap='Greys_r')

	f.tight_layout()
	#f.savefig(fig_path + 'plots_pred_' + str(id) +"_"+ class_name + ".png")
	plt.close()

    
#classes_tot = ["Buildings", "Misc. structures", "Road", "Track", "Trees", "Crops",
               #"Waterway","Standing Water", "Vehicle Large", "Vehicle Small"]

	
	return f







if __name__ == '__main__':
		
	# for i in range(n_figures):

		# show_prediction(x,y,prediction,np.random.randint(len(x)),classes,save_fig_path,trs=0.1) 
		
		
	if  os.path.exists(output_path_val):
	
		prediction = np.load(output_path_val)
		
	
	else:
	
		model= get_unet_64(n_ch = n_channels, patch_height = height_crop, patch_width = width_crop,n_classes=N_Cls)
		model.load_weights(path_model)
		
		prediction_val = model.predict(x_val)
		
		np.save(output_path_val,prediction_val)
		
	
	if  os.path.exists(output_path_tr):
		
		training = np.load(output_path_tr)
	
	else:
	
		model= get_unet_64(n_ch = n_channels, patch_height = height_crop, patch_width = width_crop,n_classes=N_Cls)
		model.load_weights(path_model)
		
		prediction_tr = model.predict(x_tr)
		
		np.save(output_path_tr,prediction_tr)


	
	
	
	from matplotlib.backends.backend_pdf import PdfPages

	

	pdf = PdfPages(save_fig_path + '_plots_pred'+ ".pdf")


	for i in range(n_figures):
		  
		
		fig=show_prediction(x_val,y_val,prediction_val,np.random.randint(len(x_val)), classes,save_fig_path,trs=0.5) 

		pdf.savefig(fig)

		# destroy the current figure
		# saves memory as opposed to create a new figure
		plt.clf()
		

	pdf.close()
	
	
	
	
	pdf = PdfPages(save_fig_path + '_plots_trn'+ ".pdf")


	for i in range(n_figures):
		  
		
		fig=show_prediction(x_tr,y_tr,prediction_tr,np.random.randint(len(x_val)), classes,save_fig_path,trs=0.5) 

		pdf.savefig(fig)

		# destroy the current figure
		# saves memory as opposed to create a new figure
		plt.clf()
		

	pdf.close()
	