import matplotlib.pyplot as plt
import numpy as np
import cv2
import pandas as pd
from shapely.wkt import loads as wkt_loads
import tifffile as tiff
from tifffile import imsave
import os
import random
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers import Input, merge, Conv2D, MaxPooling2D, UpSampling2D, Reshape, core, Dropout, Cropping2D, ZeroPadding2D
from keras.optimizers import Adam
from keras.layers.merge import concatenate
from keras.callbacks import ModelCheckpoint, LearningRateScheduler
from keras import backend as K
from sklearn.metrics import jaccard_similarity_score
from shapely.geometry import MultiPolygon, Polygon
import shapely.wkt
import shapely.affinity
from collections import defaultdict
import pdb
import random
import imutils
from tqdm import tqdm



inDir = './kaggle_dstl'
path_images_M='/mnt/users/catalano/sixteen_band/sixteen_band/'
path_images_RGB='/mnt/users/catalano/three_band/three_band/'
path_images_REG_IMG='/mnt/users/catalano/registered_img/'



DF= pd.read_csv(inDir + '/train_wkt_v4.csv')
GS = pd.read_csv(inDir + '/grid_sizes.csv', names=['ImageId', 'Xmax', 'Ymin'], skiprows=1)

id_list=sorted(DF.ImageId.unique())

SB = pd.read_csv(os.path.join(inDir, 'sample_submission.csv'))
size=3600
smooth = 1e-12  #for jaccard 


def _convert_coordinates_to_raster(coords, img_size, xymax):
    # __author__ = visoft
    # https://www.kaggle.com/visoft/dstl-satellite-imagery-feature-detection/export-pixel-wise-mask
    Xmax, Ymax = xymax
    H, W = img_size
    W1 = 1.0 * W * W / (W + 1)
    H1 = 1.0 * H * H / (H + 1)
    xf = W1 / Xmax
    yf = H1 / Ymax
    coords[:, 1] *= yf
    coords[:, 0] *= xf
    coords_int = np.round(coords).astype(np.int32)
    return coords_int


def _get_xmax_ymin(grid_sizes_panda, imageId):
    # __author__ = visoft
    # https://www.kaggle.com/visoft/dstl-satellite-imagery-feature-detection/export-pixel-wise-mask
    xmax, ymin = grid_sizes_panda[grid_sizes_panda.ImageId == imageId].iloc[0, 1:].astype(float)
    return (xmax, ymin)


def _get_polygon_list(wkt_list_pandas, imageId, cType):
    # __author__ = visoft
    # https://www.kaggle.com/visoft/dstl-satellite-imagery-feature-detection/export-pixel-wise-mask
    df_image = wkt_list_pandas[wkt_list_pandas.ImageId == imageId]
    multipoly_def = df_image[df_image.ClassType == cType].MultipolygonWKT
    polygonList = None
    if len(multipoly_def) > 0:
        assert len(multipoly_def) == 1
        polygonList = wkt_loads(multipoly_def.values[0])
    return polygonList


def _get_and_convert_contours(polygonList, raster_img_size, xymax):
    # __author__ = visoft
    # https://www.kaggle.com/visoft/dstl-satellite-imagery-feature-detection/export-pixel-wise-mask
    perim_list = []
    interior_list = []
    if polygonList is None:
        return None
    for k in range(len(polygonList)):
        poly = polygonList[k]
        perim = np.array(list(poly.exterior.coords))
        perim_c = _convert_coordinates_to_raster(perim, raster_img_size, xymax)
        perim_list.append(perim_c)
        for pi in poly.interiors:
            interior = np.array(list(pi.coords))
            interior_c = _convert_coordinates_to_raster(interior, raster_img_size, xymax)
            interior_list.append(interior_c)
    return perim_list, interior_list


def _plot_mask_from_contours(raster_img_size, contours, class_value=1):
    # __author__ = visoft
    # https://www.kaggle.com/visoft/dstl-satellite-imagery-feature-detection/export-pixel-wise-mask
    img_mask = np.zeros(raster_img_size, np.uint8)
    if contours is None:
        return img_mask
    perim_list, interior_list = contours
    cv2.fillPoly(img_mask, perim_list, class_value)
    cv2.fillPoly(img_mask, interior_list, 0)
    return img_mask


def generate_mask_for_image_and_class(raster_size, imageId, class_type, grid_sizes_panda=GS, wkt_list_pandas=DF):
    xymax = _get_xmax_ymin(grid_sizes_panda, imageId)
    polygon_list = _get_polygon_list(wkt_list_pandas, imageId, class_type)
    contours = _get_and_convert_contours(polygon_list, raster_size, xymax)
    mask = _plot_mask_from_contours(raster_size, contours, 1)
    return mask



def M(ids):
    
    filename_M = os.path.join(path_images_M,'{}_M.tif'.format(ids))
    filename_RGB = os.path.join(path_images_RGB,'{}.tif'.format(ids))
    filename_GREY = os.path.join(path_images_M, '{}_P.tif'.format(ids))
    filename_A = os.path.join(path_images_M,'{}_A.tif'.format(ids))

    img_M = tiff.imread(filename_M)
    img_M = np.rollaxis(img_M, 0, 3)
    img_M=cv2.resize(img_M,(size,size))

    img_RGB = tiff.imread(filename_RGB)
    img_RGB = np.rollaxis(img_RGB, 0, 3)
    img_RGB=cv2.resize(img_RGB,(size,size))

    img_A = tiff.imread(filename_A)
    img_A = np.rollaxis(img_A, 0, 3)
    img_A=cv2.resize(img_A,(size,size))

    img_GREY = tiff.imread(filename_GREY)
    img_GREY = cv2.resize(img_GREY,(size,size))

    swir_1   = img_A[:,:,0]
    red      = img_M[:,:,0]
    red_edge = img_M[:,:,1]
    coastal  = img_M[:,:,2]
    NIR_1    = img_M[:,:,6]
    Green    = img_M[:,:,4]

    ccci_band  = ((swir_1-red_edge)/(swir_1+red_edge))/((swir_1-red)/(swir_1+red))

    #evi_band   = 2.5*(swir_1-red_edge)/(swir_1+6*red_edge-7.5*(coastal)+1)

    ndvi_band  = (swir_1-NIR_1)/(swir_1+NIR_1)

    ndwi_band  = (Green-NIR_1)/(Green+NIR_1)

    savi_band = (swir_1- 1.22*red_edge-0.03)/(1.22*swir_1+red_edge-1.22*0.03+0.08*(1+1.22**2))



    img_TOT=np.zeros((img_RGB.shape[0],img_RGB.shape[1],24),"float32")


    img_TOT[:,:,0:3]=img_RGB
    img_TOT[:,:,3]=img_GREY
    img_TOT[:,:,4:12]=img_M
    img_TOT[:,:,12:20]=img_A


    # img_TOT[:,:,13] = evi_band
    img_TOT[:,:,20] = ndvi_band
    img_TOT[:,:,21] = ndwi_band
    img_TOT[:,:,22] = savi_band
    img_TOT[:,:,23] = ccci_band

    return img_TOT,img_RGB

def registered_reader(id):

	filename_reg = os.path.join(path_images_REG_IMG+'reg_img_'+ id +'.tif')
	img_reg= tiff.imread(filename_reg)
	
	return img_reg
	

def normalize(bands, lower_percent=2, higher_percent=98):
	
    out = np.zeros_like(bands,"float32")
    n = bands.shape[2]

    for i in range(n):
        
        a = 0  
        b = 1  
        bands_tmp=bands[:,:,i]
        c = np.amin(bands_tmp)
        d = np.amax(bands_tmp)
        t = a+(bands_tmp - c) * (b - a) / (d - c)
        out[:, :, i] = t

    return out

def percentile_cut(bands, lower_percent,higher_percent):
    
    out=np.zeros((bands.shape[0], bands.shape[1], 3),"float")
    
    for i in range(3):
       
        t=bands[:,:,i]
        c = np.percentile(t, lower_percent)
        d = np.percentile(t, higher_percent)
        t[t < c] = c
        t[t > d] = d
        out[:,:, i] = t
    
    return out


def align_two_rasters(id):

	p1=M(id)

	p_orig = p1[:,:,0].astype(np.float)

	img3=np.zeros((p1.shape[0],p1.shape[1],p1.shape[2]),"float32")


	for i in range(1,p1.shape[2]):
		
		try:
			warp_mode = cv2.MOTION_EUCLIDEAN
			warp_matrix = np.eye(2, 3, dtype=np.float32)
			criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 1000,  1e-7)
			(cc, warp_matrix) = cv2.findTransformECC (p_orig,p1[:,:,i],warp_matrix, warp_mode, criteria,None,5)
			print("_align_two_rasters: cc:{}".format(cc))

			img3[:,:,i] = cv2.warpAffine(p1[:,:,i], warp_matrix, (p_orig.shape[1], p_orig.shape[0]), flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP)
			img3[:,:,i][img3[:,:,i] == 0] = np.average(img3[:,:,i])
		
		except:
			
			img3[:,:,i]=p1[:,:,i]
			
	img3[:,:,0]=p_orig
		
	return img3


def standardize(data):

	means = np.mean(data,axis=(0,2,3))
	std= np.std(data,axis =(0,2,3))

	for k in range(data.shape[1]):
		data[:,k,:,:] -= means[k]
		data[:,k,:,:]  = data[:,k,:,:]/std[k]
		
	return data        

def jaccard_coef(y_true, y_pred):
    # __author__ = Vladimir Iglovikov
    intersection = K.sum(y_true * y_pred, axis=[0, -1, -2])
    sum_ = K.sum(y_true + y_pred, axis=[0, -1, -2])

    jac = (intersection + smooth) / (sum_ - intersection + smooth)

    return K.mean(jac)


def jaccard_coef_int(y_true, y_pred):
    # __author__ = Vladimir Iglovikov
    y_pred_pos = K.round(K.clip(y_pred, 0, 1))

    intersection = K.sum(y_true * y_pred_pos, axis=[0, -1, -2])
    sum_ = K.sum(y_true + y_pred_pos, axis=[0, -1, -2])
    jac = (intersection + smooth) / (sum_ - intersection + smooth)
    return K.mean(jac)         