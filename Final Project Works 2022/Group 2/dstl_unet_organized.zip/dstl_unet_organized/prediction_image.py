#!/usr/bin/env python
# coding: utf-8

# In[1]:


import matplotlib.pyplot as plt
import numpy as np
import cv2
import pandas as pd
from shapely.wkt import loads as wkt_loads
import matplotlib.pyplot as plt
import tifffile as tiff
import os
import random
from keras.models import Model
from keras.layers.normalization import BatchNormalization
from keras.layers import *
from keras.optimizers import Adam
from keras.layers.merge import concatenate
from keras.callbacks import ModelCheckpoint, LearningRateScheduler
from keras import backend as K
from sklearn.metrics import jaccard_similarity_score
from sklearn.preprocessing import minmax_scale
from shapely.geometry import MultiPolygon, Polygon
import shapely.wkt
import shapely.affinity
from collections import defaultdict
import pdb
import random
import imutils
import sys,csv
from collections import Counter #mia
import numpy as np
from tifffile import imsave
from tqdm import tqdm
import matplotlib as mpl

plt.rcParams.update({'font.size': 20})

from model_unet import *
from utils import *
from val_train_creator import *
from model_training import *
# In[2]:





def predict_img(model,idx,img_all):
    
    size=3600
    patch=256
    slide=200

    padding=28

    

    img_all=np.pad(img_all, ((padding, padding),(padding,padding),(0,0)), 'symmetric')
    img_all=np.expand_dims(img_all, axis=0)
    img = np.transpose(img_all, (0,3,1,2))

    
    mask = np.zeros((size,size),'float')
    
    
    for i in tqdm(range(18)):
 
        for j in range(18):


                out_pred=model.predict(img[:,:,i*slide: patch+i*slide,j*slide:patch+j*slide])
                #print(out_pred.shape)
                mask[i*slide:slide+i*slide,j*slide:slide+j*slide]=out_pred[0,0,:,:]
                
    return mask        


# In[11]:


def aug_predict(model,idx):
    
    size=3600


    img_all = M(idx)[0]
    img_all = normalize(img_all)



    mask_list = np.zeros((0,size,size),'float')

    #rotation
    for i in range(4):
        
        mask_pred=predict_img(model,idx,np.rot90(img_all,i))
        mask_pred=np.expand_dims(mask_pred,axis=0)
        mask_list=np.concatenate((mask_list,mask_pred))

    #flip left-right
    mask_lr = np.fliplr(img_all)

    mask_pred=predict_img(model,idx,mask_lr)

    mask_pred=np.expand_dims(mask_pred,axis=0)
    mask_list=np.concatenate((mask_list,mask_pred))

    #flip up-down
    mask_ud = np.flipud(img_all)

    mask_pred=predict_img(model,idx,mask_ud)

    mask_pred=np.expand_dims(mask_pred,axis=0)
    mask_list=np.concatenate((mask_list,mask_pred))


    #return back

    mask_list[0]=mask_list[0]
    mask_list[1]=np.rot90(mask_list[1],3)
    mask_list[2]=np.rot90(mask_list[2],2)
    mask_list[3]=np.rot90(mask_list[3],1)
    mask_list[4]=np.fliplr(mask_list[4])
    mask_list[5]=np.flipud(mask_list[5])

    return np.sum(mask_list,axis=0)/6,np.sqrt(np.prod(mask_list,axis=0)),mask_list
    
    


# In[12]:


def plot_mask(pred_mask,id_img,class_type):
    
    size=3600
    img_M = M(id_img)[0]
    
    image = np.zeros((img_M.shape[0], img_M.shape[1], 3),"int")
    image=percentile_cut(img_M,2,98)


    image[:, :, 0] = minmax_scale(img_M[:, :, 0] , feature_range=(0, 255), axis=0, copy=True) # red
    image[:, :, 1] = minmax_scale(img_M[:, :, 1] , feature_range=(0, 255), axis=0, copy=True)  # green
    image[:, :, 2] = minmax_scale(img_M[:, :, 2] , feature_range=(0, 255), axis=0, copy=True)  # blue

    print(id_img)
    mask_orig = generate_mask_for_image_and_class((size, size), id_img, band_class + 1)
    print(mask_orig.shape)
    
    fig,axx=plt.subplots(1,3,figsize=(24,24))

    trs=0.95
    
    
    
    mask_tr_up=pred_mask[:,:]>=trs
    mask_tr_bot=pred_mask[:,:]<trs
    pred_mask[mask_tr_up]=1
    pred_mask[mask_tr_bot]=0
    
   
    
    jacc_coeff=np.round(jaccard_predict(mask_orig,pred_mask),3)
    
    jacc_coeff_val=np.round(jaccard_predict(mask_orig[int(3600/2)::,int(3600/2)::],pred_mask[int(3600/2)::,int(3600/2)::]),3)
    
    val_mask_col=pred_mask[int(3600/2)::,int(3600/2)::]*2
    
    tmp_mask=pred_mask
    tmp_mask[int(3600/2)::,int(3600/2)::]=val_mask_col
    
    cmap_my = mpl.colors.ListedColormap(['black', 'white', 'yellow', ])
    
    axx[0].imshow(mask_orig,figure=fig)
    tiff.imshow(image,figure=fig,subplot=axx[1])
    axx[1].set_title(' {} : {}\n\n jaccard coeff: {}\n\njaccard coeff val:{}\n \n'.format(id_img,class_type,jacc_coeff,jacc_coeff_val))
    axx[2].imshow(pred_mask,cmap=cmap_my,vmin=0,vmax=2,figure=fig)
    axx[2].axvline(x=1800,ymin=0,ymax=0.5,color='yellow')
    axx[2].axhline(y=1800,xmin=0.5,xmax=1,color='yellow')
    #axx[2].set_xlabel(id_img)
    #plt.show()
    
    


# In[13]:



def jaccard_predict(y_true,y_pred):
    
    #y_pred_pos = K.round(K.clip(y_pred, 0, 1))

    intersection = np.sum(y_true.flatten() * y_pred.flatten())
    sum= np.sum(y_true.flatten() + y_pred.flatten())
    jac = (intersection + smooth) / (sum - intersection + smooth)
    return jac


# In[20]:


def plot_mask_orig(size,class_type,plt=False):
    
    
    ids = sorted(DF.ImageId.unique())
    classes_tot = ["Buildings", "Misc. structures", "Road", "Track", "Trees", "Crops",
                        "Waterway","Standing Water", "Vehicle Large", "Vehicle Small"]

    class_dict=dict(zip(classes_tot,range(10)))

    band_class=class_dict[class_type]

    img = M(ids[8],3600)[1]
    img_shape=img.shape
    mask_orig = np.zeros((25,img_shape[0], img_shape[1]),'int')


    for i in tqdm(range(len(ids))):


        mask_orig[i,:,:] = generate_mask_for_image_and_class((img_shape[0], img_shape[1]), ids[i], band_class + 1)
        

    area_list=np.zeros((len(ids)))

    for k in tqdm(range(len(ids))):


        area_list[k]=np.round(np.sum(mask_orig[k,:,:])/len(mask_orig[k,:,:].flatten()),4)
        
        
    ids_list_buildings=np.array([ [i,ids[i]] for i in range(len(ids)) if  area_list[i] ])

    dict_ids_val=dict(zip(ids_list_buildings[:,1],ids_list_buildings[:,0]))

    if plt:

        for k,v in dict_ids_val.items():


            plt.figure(figsize=(24,24))

            plt.imshow(mask_orig[int(v),:,:])
            plt.xlabel(k+'_idx_'+v)


            plt.show()

    return mask_orig


if __name__ == '__main__':

    valid_idx_band={0: [7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19],
                    1: [0, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,18, 19, 20], 
                    2: [8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19],
                    3: [0, 1, 3, 4, 5, 6, 7, 9, 10, 11, 12,14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
                    4: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24], 
                    5: [4, 7, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 23],
                    6: [8, 11], 
                    7: [8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 22, 23], 
                    8: [10, 11, 12, 14, 15, 16, 17],
                    9: [8, 10, 11, 12, 13, 14, 16, 17, 18, 19]}    
                        
    band_class=4
    class_type='Trees'
    model_unet='model_unet_800_24_1_50_4_Trees'
    type_agg=1
    
    valid_image=[id_list[i]  for i in valid_idx_band[band_class]]

    print(valid_image)

    
    model=get_unet_64(n_ch=24)
    model.load_weights('./weights/'+model_unet)

    pred_all=np.zeros((len(valid_image),size,size))

    i=0
    for ids in tqdm(valid_image):

        pred_all[i,:,:]=aug_predict(model,ids)[type_agg]
        i+=1
        
    np.save("pred_all_img_"+class_type+".npy",pred_all)
    
    pred_all_img=np.load("pred_all_img_"+class_type+".npy")

    from matplotlib.backends.backend_pdf import PdfPages

    

    pdf = PdfPages('./output_pred/plot_prediction/{}{}'.format(class_type,'/')+model_unet+"_img_pred_"+str(type_agg) + ".pdf")


    for i in tqdm(range(pred_all_img.shape[0])):
          
       

        fig=plot_mask(pred_all_img[i,:,:],valid_image[i],class_type)

        pdf.savefig(fig)

        # destroy the current figure
        # saves memory as opposed to create a new figure
        plt.clf()


    pdf.close()