'''
Created on 14/05/2022

@author: Francesco Pugliese
'''

import numpy as np
import tensorflow as tf
import pickle
from keras.layers import LSTM, Embedding, Input, Dense
from keras.callbacks import ModelCheckpoint, CSVLogger
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
from keras.models import Model, load_model
from keras.activations import softmax
from keras.optimizers import RMSprop

import requests, zipfile, io

import os
import yaml
import pdb
import warnings
import pdb

with warnings.catch_warnings():
    warnings.filterwarnings("ignore",category=DeprecationWarning)
    
hiddent_dim = 200    

# Set CPU or GPU type
gpu = False
gpu_id = "0"
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"  
if gpu == False: 
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
else: 
    os.environ["CUDA_VISIBLE_DEVICES"] = gpu_id

dir_path = '../../Datasets/Chatterbot_dataset'
files_list = os.listdir(dir_path + os.sep)


def str_to_tokens(sentence : str, word_index, maxlen_questions):
    words = sentence.lower().split()
    tokens_list = list()
    for word in words:
        if word in word_index:
          tokens_list.append(word_index[word]) 
    return pad_sequences([tokens_list], maxlen=maxlen_questions, padding='post')

#enc_model, dec_model = make_inference_models()

def get_response(input_text, model, word_index, maxlen_questions, maxlen_answers):

    #print("Get response is called from server")

    encoder_inputs = model.input[0]  
    encoder_outputs, state_h_enc, state_c_enc = model.layers[4].output   
    encoder_states = [state_h_enc, state_c_enc]
    enc_model = Model(encoder_inputs, encoder_states)

    states_values = enc_model.predict(str_to_tokens(input_text, word_index, maxlen_questions))
 
    decoder_inputs = model.input[1]  
    decoder_embedding = model.layers[3]
    decoder_embedding = decoder_embedding(decoder_inputs)
    decoder_state_input_h = Input(shape=(hiddent_dim,), name='input_3')
    decoder_state_input_c = Input(shape=(hiddent_dim,), name='input_4')
    decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]
    decoder_lstm = model.layers[5]
    decoder_outputs, state_h, state_c = decoder_lstm(decoder_embedding, initial_state=decoder_states_inputs)
    decoder_states = [state_h, state_c]
    decoder_dense = model.layers[6]
    decoder_outputs = decoder_dense(decoder_outputs)
    dec_model = Model([decoder_inputs] + decoder_states_inputs, [decoder_outputs] + decoder_states)

    empty_target_seq = np.zeros( ( 1 , 1 ) )
    empty_target_seq[0, 0] = word_index['start']
    stop_condition = False
    decoded_translation = ''
    while not stop_condition :
        dec_outputs , h , c = dec_model.predict([ empty_target_seq ] + states_values )
        
        sampled_word_index = np.argmax( dec_outputs[0, -1, :] )
        sampled_word = None
        for word , index in word_index.items() :
            if sampled_word_index == index :
                decoded_translation += ' {}'.format( word )
                sampled_word = word
        
        if sampled_word == 'end' or len(decoded_translation.split()) > maxlen_answers:
            stop_condition = True
            
        empty_target_seq = np.zeros( ( 1 , 1 ) )  
        empty_target_seq[ 0 , 0 ] = sampled_word_index
        states_values = [ h , c ]

    return decoded_translation
    #print( decoded_translation.rsplit(' ', 1)[0] )

# Loading the neural chatbot model
#model = load_model('best_chatbot.hdf5')
model = load_model('last_epoch_chatbot.hdf5')

# Loading the chatbot word index
with open('neural_chatbot_wi.pkl', 'rb') as handle:
    word_index = pickle.load(handle)
    maxlen_questions = pickle.load(handle)
    maxlen_answers = pickle.load(handle)
    
input_text = ''

while(input_text != 'stop'):
  input_text = input('Enter question : ')
  print(get_response(input_text, model, word_index, maxlen_questions, maxlen_answers))
