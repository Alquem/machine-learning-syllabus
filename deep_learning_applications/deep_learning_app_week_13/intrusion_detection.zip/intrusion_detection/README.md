# deep_learning_computer_vision_engine
An Universal Deep Learning Engine for Satellite Imagery classification, Cancer Classification, Rubbish classification, etc. 
