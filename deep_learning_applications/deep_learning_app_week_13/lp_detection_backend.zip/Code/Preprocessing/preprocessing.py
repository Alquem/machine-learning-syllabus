'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

from Misc.mongo_wrapper import MongoWrapper as mdb 
from View.view import View 
from sklearn.model_selection import StratifiedShuffleSplit, train_test_split
from sklearn.preprocessing import LabelEncoder, MinMaxScaler

import pandas as pd
import glob
import cv2

# import keras 
import tensorflow
if tensorflow.__version__ > '2.0.0':
    from tensorflow.keras.datasets import mnist
    from tensorflow.keras.preprocessing.image import array_to_img, img_to_array
    from tensorflow.keras.utils import to_categorical
    from tensorflow.keras.preprocessing.image import load_img
else:
    from keras.datasets import mnist
    from keras.preprocessing.image import array_to_img, img_to_array
    from keras.utils import to_categorical
    from keras.preprocessing.image import load_img

# import os
import os
from os.path import isfile, isdir, join
import pdb

#other imports
import numpy as np
import timeit
from imutils import paths

class Preprocessing(object):
    def __init__(self, params):
        self.__params = params
    
    def load_characters_dataset_from_local_disk(self, __params):
        print ("\nLoading Characters Dataset from the Local Disk...")

        # load data
        load_start_time = timeit.default_timer()
        # grab the image paths and randomly shuffle them
        imagePaths = sorted(list(paths.list_images(self.__params.characters_recognition_dataset_path)))
        
        # loop over the input images
        data = []
        labels = []
        count = 0
        for imagePath in imagePaths:
            
            # load the image, pre-process it, and store it in the data list
            image = cv2.imread(imagePath)

            if self.__params.characters_recognition_rescale == True: 
                image = cv2.resize(image, (self.__params.characters_recognition_input_size, self.__params.characters_recognition_input_size))
            image = img_to_array(image)
            data.append(image)
            # extract the class label from the image path and update the labels list
            label = imagePath.split(os.path.sep)[-2]
            labels.append(label)
            
            if self.__params.limit is not None:
                count += 1
                
                if count>=self.__params.limit:
                    break

        data_set = np.array(data, dtype="float16")
        labels = np.array(labels)
       
        n_channels = data_set.shape[3]

        # split the data into a training set and a validation set
        indices = np.arange(data_set.shape[0])

        if self.__params.shuffle == True: 
            np.random.shuffle(indices)
            
        data_set = data_set[indices]
        labels = labels[indices]
        
        n_classes = len(np.unique(labels))
        
        # perform one-hot encoding on the labels
        lb = LabelEncoder()
        lb.fit(labels)
        labels = lb.transform(labels)

        # save label file so we can use in another script
        np.save(self.__params.characters_recognition_models_path + '/labels.npy', lb.classes_)

        num_validation_samples = int(round(self.__params.valid_set_perc * data_set.shape[0]))
        num_test_samples = int(round(self.__params.test_set_perc * data_set.shape[0]))
        train_set_x = data_set[:-(num_test_samples+num_validation_samples)]
        train_set_y = labels[:-(num_test_samples+num_validation_samples)]
        val_set_x = data_set[-(num_test_samples+num_validation_samples):-num_test_samples]
        val_set_y = labels[-(num_test_samples+num_validation_samples):-num_test_samples]
        test_set_x = data_set[-num_test_samples:]
        test_set_y = labels[-num_test_samples:]

        # Normalization
        train_set_x /= 255
        val_set_x /= 255
        test_set_x /= 255

        # Convert labels to categorical one-hot encoding
        train_set_y = to_categorical(train_set_y, num_classes = n_classes)
        val_set_y = to_categorical(val_set_y, num_classes = n_classes)
        test_set_y = to_categorical(test_set_y, num_classes = n_classes)

        print ('\n\nLoading time: %.2f minutes\n' % ((timeit.default_timer() - load_start_time) / 60.))

        return [train_set_x, train_set_y, val_set_x, val_set_y, test_set_x, test_set_y, n_channels, n_classes]

    def load_characters_dataset_from_local_disk2(self, __params):
        print ("\nLoading Characters Dataset from the Local Disk...")

        # load data
        load_start_time = timeit.default_timer()

        dataset_paths = glob.glob(self.__params.characters_recognition_dataset_path+"/**/*.jpg")
        
        # Arange input data and corresponding labels
        X=[]
        labels=[]

        for image_path in dataset_paths:
          label = image_path.split(os.path.sep)[-2]
          image=load_img(image_path,target_size=(80,80))
          image=img_to_array(image)

          X.append(image)
          labels.append(label)

        X = np.array(X,dtype="float16")
        labels = np.array(labels)
                
        n_channels = X.shape[3]
        n_classes = len(np.unique(labels))

        print("[INFO] Find {:d} images with {:d} classes".format(len(X),len(set(labels))))

        # perform one-hot encoding on the labels
        lb = LabelEncoder()
        lb.fit(labels)
        labels = lb.transform(labels)
        y = to_categorical(labels)

        # save label file so we can use in another script
        np.save('./license_character_classes.npy', lb.classes_)

        # split 10% of data as validation set
        (trainX, testX, trainY, testY) = train_test_split(X, y, test_size=0.10, stratify=y, random_state=42)
    
        print ('\n\nLoading time: %.2f minutes\n' % ((timeit.default_timer() - load_start_time) / 60.))

        return [trainX, trainY, testX, testY, testX, testY, n_channels, n_classes]

    def load_license_plate_detection_data_from_local_disk(image_path, resize=False, verbose=False):
        
        if verbose == True:
            print ("\nLoading data from the Local Disk...")

        img = cv2.imread(image_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = img / 255
        if resize:
            img = cv2.resize(img, (224,224))
        return img

    def load_license_plate_detection_data_from_mongodb(self, __params):
        return None
