'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

import matplotlib.pyplot as plt

import matplotlib
matplotlib.use('Agg')

import matplotlib.gridspec as gridspec
from os.path import splitext, basename

from io import BytesIO
import base64


class View: 


    # Convert the plot in to base64 format
    @staticmethod
    def get_plot_64(plt_IObytes):

        plt_64 = ''
        plt.savefig(plt_IObytes,  format='png')
        plt_64 = base64.encodestring(plt_IObytes.getvalue())

        plt_64 = plt_64.decode('utf8')
        plt_64 = "data:image/png;base64," + plt_64

        return plt_64

    # Plot the loss function chart
    @staticmethod
    def save_and_plot_cars_dataset(image_paths, output_path, plot):

        # Visualize data in subplot 
        fig = plt.figure(figsize=(12,8))
        cols = 5
        rows = 4
        fig_list = []
        for i in range(cols*rows):
            fig_list.append(fig.add_subplot(rows,cols,i+1))
            title = splitext(basename(image_paths[i]))[0]
            fig_list[-1].set_title(title)
            img = Utilities.preprocess_image(image_paths[i],True)
            plt.axis(False)
            plt.imshow(img)

        plt.tight_layout(True)
        
        plt.savefig(output_path + "/input_cars.jpg")
        
        if plot == True: 
            plt.show(block=False)
            plt.pause(1)
        
        plt.close()
            
    @staticmethod
    def save_and_plot_vehicle_and_plate(vehicle, LpImg, output_path, plot, flag_64):
        
        plt_IO = BytesIO()
        
        # Visualize our result
        plt.figure(figsize=(12,5))
        plt.subplot(1,2,1)
        plt.axis(False)
        plt.imshow(vehicle)
        plt.subplot(1,2,2)
        plt.axis(False)
        plt.imshow(LpImg[0])

        plt_64 = ''
        if flag_64 == True:
            plt_64 = View.get_plot_64(plt_IO)
        else:
            plt.savefig(output_path + "/license_plate.png",dpi=300)

        if plot == True: 
            plt.show(block=False)
            plt.pause(1)

        plt.close()

        return plt_64
            
    @staticmethod
    def save_and_plot_filtered_plate(filtered_images_list, output_path, plot, flag_64):

        plt_IO = BytesIO()

        # visualize results   
        fig = plt.figure(figsize=(12,7))
        plt.rcParams.update({"font.size":18})
        grid = gridspec.GridSpec(ncols=2,nrows=3,figure = fig)
        plot_image = filtered_images_list
        plot_name = ["plate_image","gray","blur","binary","dilation"]

        for i in range(len(plot_image)):
            fig.add_subplot(grid[i])
            plt.axis(False)
            plt.title(plot_name[i])
            if i ==0:
                plt.imshow(plot_image[i])
            else:
                plt.imshow(plot_image[i],cmap="gray")


        plt_64 = ''
        if flag_64 == True:
            plt_64 = View.get_plot_64(plt_IO)
        else:
            plt.savefig(output_path + "/segmented_plate.png",dpi=300)

        if plot == True: 
            plt.show(block=False)
            plt.pause(1)
        
        plt.close()

        return plt_64
            
    @staticmethod
    def save_and_plot_separated_plate_characters(test_roi, crop_characters, output_path, plot, flag_64):
        
        plt_IO = BytesIO()

        fig = plt.figure(figsize=(10,6))
        plt.axis(False)
        plt.imshow(test_roi)

        plt_64_1 = ''
        if flag_64 == True:
            plt_64_1 = View.get_plot_64(plt_IO)
        else:
            plt.savefig(output_path + "/digit_contour.png",dpi=300)
        
        if plot == True: 
            plt.show(block=False)
            plt.pause(1)

        plt.close()

        plt_IO = BytesIO()

        fig = plt.figure(figsize=(14,4))
        grid = gridspec.GridSpec(ncols=len(crop_characters), nrows=1,figure=fig)

        for i in range(len(crop_characters)):
            fig.add_subplot(grid[i])
            plt.axis(False)
            plt.imshow(crop_characters[i],cmap="gray")

        plt_64_2 = ''
        if flag_64 == True:
            plt_64_2 = View.get_plot_64(plt_IO)
        else:
            plt.savefig(output_path + "/segmented_letters.png",dpi=300)
          
        if plot == True: 
            plt.show(block=False)
            plt.pause(1)
        
        plt.close()
        
        return plt_64_1, plt_64_2

    @staticmethod
    # Plot the accuracy function chart
    def plot_acc(history, plot):
        plt.figure() # generate a new window
        plt.plot(history.history['accuracy'], label='train_acc')
        plt.plot(history.history['val_accuracy'], label='val_acc')
        plt.legend(loc='upper left')
        plt.savefig("accuracy.jpg")
        if plot == True: 
            plt.show(block=False)
            plt.pause(1)        