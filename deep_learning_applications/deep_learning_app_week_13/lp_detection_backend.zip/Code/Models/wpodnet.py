'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

from os.path import splitext
import pdb
import tensorflow
if tensorflow.__version__ > '2.0.0':
    from tensorflow.keras.models import model_from_json
else:
    from keras.models import model_from_json

from Misc.reconstruction_utils import detect_lp

class WPodNet:
    @staticmethod
    def build(depth, height, width, classes, summary):
    
        if summary == True:
            model.summary()
                
        return model         
        
    def load_model(path, summary, show_output_messages):
        try:
            path = splitext(path)[0]
            with open('%s.json' % path, 'r') as json_file:
                model_json = json_file.read()
            model = model_from_json(model_json, custom_objects={})
            model.load_weights('%s.h5' % path)
            if show_output_messages == True:
                print("Loading model successfully...")

            if summary == True:
                model.summary()

            return model
        except Exception as e:
            print(e)
            
    # forward image through model and return plate's image and coordinates
    # if error "No Licensese plate is founded!" pop up, try to adjust Dmin
    def get_plate(vehicle, wpod_net, image_path, Dmax=608, Dmin=256): # 608,256 - 648,280 - 860,360
        ratio = float(max(vehicle.shape[:2])) / min(vehicle.shape[:2])
        side = int(ratio * Dmin)
        LpImg = None
        cor = None
        
        try:
            bound_dim = min(side, Dmax)
            _ , LpImg, _, cor = detect_lp(wpod_net, vehicle, bound_dim, lp_threshold=0.5)
        except:
            print("No license plate detected.")


        return LpImg, cor
