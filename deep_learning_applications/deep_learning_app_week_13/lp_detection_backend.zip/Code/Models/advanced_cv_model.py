'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

import tensorflow
if tensorflow.__version__ > '2.0.0':
    from tensorflow.keras.applications.inception_v3 import InceptionV3
    from tensorflow.keras.applications.xception import Xception
    from tensorflow.keras.applications import ResNet50
    from tensorflow.keras.applications.inception_resnet_v2 import InceptionResNetV2
    from tensorflow.keras.applications.nasnet import NASNetLarge
    from tensorflow.keras.applications import MobileNetV2
    from tensorflow.keras.models import Model
    from tensorflow.keras.layers import Dense, Flatten, AveragePooling2D, GlobalAveragePooling2D, Dropout, Input
    from tensorflow.keras.regularizers import l2
    from tensorflow.keras.models import model_from_json
    from tensorflow.keras.preprocessing.image import array_to_img, img_to_array
else:
    from keras.applications.inception_v3 import InceptionV3
    from keras.applications.xception import Xception
    from keras.applications import ResNet50
    from keras.applications.inception_resnet_v2 import InceptionResNetV2
    from keras.applications.nasnet import NASNetLarge
    from keras.applications import MobileNetV2
    from keras.models import Model
    from keras.layers import Dense, Flatten, AveragePooling2D, GlobalAveragePooling2D, Dropout, Input
    from keras.regularizers import l2
    from keras.models import model_from_json
    from keras.preprocessing.image import array_to_img, img_to_array

import pdb
from os.path import splitext
import numpy as np
import cv2

import pdb
from sklearn.preprocessing import LabelEncoder

# pre-processing input images and pedict with model
def predict_from_model(image, model, labels):
    #image = cv2.imread("../Input/dataset_characters/D/47042_2.jpg", cv2.IMREAD_GRAYSCALE)
    #cv2.imshow('image', image) 
    #pdb.set_trace()
    image = cv2.resize(image,(80,80))
    image = np.stack((image,)*3, axis=-1)
    image=img_to_array(image)
    image = image[np.newaxis,:]
    image = image / image.max()
    prediction_probs = model.predict(image)
    prediction_classes = [np.argmax(prediction_probs)]
    prediction = labels.inverse_transform(prediction_classes)
    return prediction

class AdvancedCVModel:
    
    @staticmethod
    def build(neural_model, input_size, default_input_size, input_channels, model_output_n_classes, imagenet_init_weights, train_all_layers, summary):

        # Selecting whether to adopt transfer learning or not
        if imagenet_init_weights == True:
            pretrained_weights='imagenet' 
        else: 
            pretrained_weights=None
    
        if default_input_size == True: 
            if neural_model == 'resnet' or neural_model == 'inception' or neural_model == 'mobilenet': 
                model_input_height = 224
                model_input_width = 224
            elif neural_model == 'inceptionresnet' or neural_model == 'xception': 
                model_input_height = 299
                model_input_width = 299
                inputShape = (height, width, depth)
            elif neural_model == 'nasnet':
                model_input_height = 331
                model_input_width = 331
        else:
            model_input_height = input_size
            model_input_width = input_size

        if neural_model == 'xception':
            deep_network = Xception(weights=pretrained_weights, include_top=False, input_tensor=Input(shape=(model_input_width, model_input_height, input_channels)))
        elif neural_model == 'resnet':
            deep_network = ResNet50(weights=pretrained_weights, include_top=False, input_tensor=Input(shape=(model_input_width, model_input_height, input_channels)))
        elif neural_model.lower() == 'inception':
            deep_network = InceptionV3(weights=pretrained_weights, include_top=False, input_tensor=Input(shape=(model_input_width, model_input_height, input_channels)))
        elif neural_model.lower() == 'inceptionresnet':
            deep_network = InceptionResNetV2(weights=pretrained_weights, include_top=False, input_tensor=Input(shape=(model_input_width, model_input_height, input_channels)))
        elif neural_model == 'nasnet':
            deep_network = NASNetLarge(weights=pretrained_weights, include_top=False, input_tensor=Input(shape=(model_input_width, model_input_height, input_channels)))
        elif neural_model == 'mobilenet': 
            deep_network = MobileNetV2(weights=pretrained_weights, include_top=False, input_tensor=Input(shape=(model_input_width, model_input_height, input_channels)))
        else: 
            print("Neural Model not supported: ", neural_model)
            return None    
        
        if neural_model != 'mobilenet': 
            top_model = deep_network.output
            top_model = GlobalAveragePooling2D()(top_model)
            top_model = Dense(128,activation='relu')(top_model)
            top_model = Dense(256,activation='relu')(top_model)
            top_model = Dropout(0.2)(top_model)
            top_model = Dropout(0.5)(top_model)
            top_model = Dense(model_output_n_classes, kernel_regularizer = l2(0.005), activation='softmax')(top_model)
        else:
            top_model = deep_network.output
            top_model = AveragePooling2D(pool_size=(3, 3))(top_model)
            top_model = Flatten(name="flatten")(top_model)
            top_model = Dense(128, activation="relu")(top_model)
            top_model = Dropout(0.5)(top_model)
            top_model = Dense(model_output_n_classes, activation="softmax")(top_model)        
        
        model = Model(inputs=deep_network.input, outputs=top_model)
        
        # first: train only the top layers (which were randomly initialized)
        # i.e. freeze all convolutional InceptionV3 layers
        if train_all_layers == True:
            for layer in deep_network.layers:
                layer.trainable = True                  # This was the mistake!! I put False
        
        if summary==True:
            model.summary()

        # return the constructed network architecture
        return model
        
        
    @staticmethod
    def load_model(path, characters_recognition_models_path, summary, neural_model, show_output_messages):
        try:
            # Load model architecture, weight and labels
            path = splitext(path)[0]
            
            with open('%s.json' % path, 'r') as json_file:
                loaded_model_json = json_file.read()

            model = model_from_json(loaded_model_json)
            model.load_weights('%s.h5' % path)
            if show_output_messages == True:
                print("[INFO] Character Recognition Model loaded successfully...")

            labels = LabelEncoder()
            labels.classes_ = np.load(characters_recognition_models_path + '/' + neural_model + '-labels.npy')
            if show_output_messages == True:
                print("[INFO] Character Recognition Labels loaded successfully...")

            if summary == True:
                model.summary()

            return model, labels
        except Exception as e:
            print(e)
            
    @staticmethod
    def predict_plate(crop_characters, model, labels):

        final_string = ''
        
        for i, character in enumerate(crop_characters):
            title = predict_from_model(character, model, labels)
            title = np.array2string(title)
            final_string += title.strip("'[]")

        return final_string
