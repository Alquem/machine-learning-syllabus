'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

import cv2
from View.view import View
import numpy as np
import pdb
from datetime import datetime

# Create sort_contours() function to grab the contour of each digit from left to right
def sort_contours(cnts, reverse = False):
    i = 0
    boundingBoxes = [cv2.boundingRect(c) for c in cnts]
    (cnts, boundingBoxes) = zip(*sorted(zip(cnts, boundingBoxes),
                                        key=lambda b: b[1][i], reverse=reverse))
    return cnts

    def apply_adaptive_threshold(self, plate_image_median, gray):
        if plate_image_median > 205:
            adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 51, 1)
        else:
            adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 111, 10)
        return adaptive

class Segmentation:

    @staticmethod
    def plate_segmentation(license_plate, digits_segmentation_algorithm, output_path, plot, flag_64, verbose):

        #check if there is at least one license image
        if (len(license_plate)): 
        
            # Scales, calculates absolute values, and converts the result to 8-bit.
            plate_image = cv2.convertScaleAbs(license_plate[0], alpha=(255.0))
            
            # convert to grayscale and blur the image
            gray = cv2.cvtColor(plate_image, cv2.COLOR_BGR2GRAY)
            # blur = cv2.GaussianBlur(gray,(3,3),0)

            # Applied inversed thresh_binary 
            adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 61, 5)

            binary = cv2.threshold(adaptive, 180, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

            if(np.median(plate_image.ravel())>125):
                kernel4 = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
            else:
                kernel4 = cv2.getStructuringElement(cv2.MORPH_RECT, (1, 1))

            thre_mor = cv2.morphologyEx(binary, cv2.MORPH_DILATE, kernel4)

            sp_64 = View.save_and_plot_filtered_plate([plate_image, gray, binary, thre_mor], output_path, plot, flag_64)
            if digits_segmentation_algorithm == 'contour':
                cont, _  = cv2.findContours(thre_mor, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            elif digits_segmentation_algorithm == 'mser':
                mser = cv2.MSER_create()
                cont, _  = mser.detectRegions(thre_mor)
            
            # creat a copy version "test_roi" of plat_image to draw bounding box
            test_roi = plate_image.copy()

            # Initialize a list which will be used to append charater image
            crop_characters = []

            # define standard width and height of character
            digit_w, digit_h = 30, 60
            
            for c in sort_contours(cont):
                if digits_segmentation_algorithm == 'contour':
                    (x, y, w, h) = cv2.boundingRect(c)
                elif digits_segmentation_algorithm == 'mser':
                    xmax, ymax = np.amax(c, axis=0)
                    xmin, ymin = np.amin(c, axis=0)
                    h = ymax-ymin
                    w = xmax-xmin
                    x = xmin
                    y = ymin


                ratio = h / w
                # Only select contour with defined ratio 
                # and contour which has the height larger than 35% of the plate but smaller than 70%
                ratio_in_range = (1 <= ratio <= 10)
                height_in_range = (0.9 > h / plate_image.shape[0] >= 0.5)
                #width_in_range = (0.9 > w / plate_image.shape[1] >= 0.4)
                
                #if ratio_in_range & height_in_range & width_in_range:
                if ratio_in_range & height_in_range:
                    # Draw bounding box arroung digit number
                    cv2.rectangle(test_roi, (x, y), (x + w, y + h), (0, 255, 0), 2)
                                        
                    # Separate number and gibe prediction
                    curr_num = thre_mor[y:y+h,x:x+w]
                    curr_num = cv2.resize(curr_num, dsize=(digit_w, digit_h))
                    # curr_num = cv2.adaptiveThreshold(curr_num, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 41, 4)
                    _, curr_num = cv2.threshold(curr_num, 220, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

                    crop_characters.append(curr_num)

            if verbose == True:
                print("Detect {} letters...".format(len(crop_characters)))
            
            dc_64, sl_64 = View.save_and_plot_separated_plate_characters(test_roi, crop_characters, output_path, plot, flag_64)
            
        return crop_characters, sp_64, dc_64, sl_64    