'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

import configparser
from Misc.mongo_wrapper import MongoWrapper as mdb 

config = {}

mongoFlag = False

class SetParameters:
    
    def __init__(self, conf_file_path, conf_file_name, OS):
        
        self.random_seed = 77
        
        # Class Initialization (constructor) 
        self.conf_file_path = conf_file_path
        self.conf_file_name = conf_file_name
        
        # System
        self.cv_mode = 0                                                     # 0: training, 1: testing
        self.gpu = False
        self.gpu_id = '0'
        self.system_desc = 'Laptop'
        self.gpu_desc = None
        
        # MongoDB
        self.connection_string = "mongodb://adadmin:adadmin@ad2020-shard-00-00-zmesm.gcp.mongodb.net:27017,ad2020-shard-00-01-zmesm.gcp.mongodb.net:27017,ad2020-shard-00-02-zmesm.gcp.mongodb.net:27017/test?ssl=true&replicaSet=ad2020-shard-0&authSource=admin&retryWrites=true&w=majority"
        self.mdbname = "db2020"       

        # Dataset
        self.license_plate_detection_data = False
        self.license_plate_detection_path = ""
        self.license_plate_detection_train_filename = ""
        self.license_plate_detection_classification_filename = ""
        self.characters_recognition_dataset_path = ""
        self.characters_recognition_rescale = True
        self.characters_recognition_input_size = 80
        self.mnist_benchmark = False
        
        # Preprocessing
        self.imagenet_init_weights = False
        self.default_input_size = False
        self.data_augmentation = False
        self.valid_set_perc = 3                                          # Validation set percentage with respect to the Training Set
        self.test_set_perc = 3                                           # Test set percentage with respect to the entire Data Set
        self.normalize_x = False                                         # Normalize input between 0 and 1, time-consuming for bigger datasets
        self.normalize_y = False                                         # Normalize input between 0 and 1, time-consuming for bigger datasets
        self.limit = None
        self.shuffle = False
        
        # Segmentation
        self.digits_segmentation_model = 'opencv'
        self.digits_segmentation_algorithm = 'mser'

        # Model
        self.end_to_end = False
        self.plates_localization_model = 'wpodnet'
        self.characters_recognition_neural_model = 'mobilenet'
        self.license_plate_detection_models_path = ""
        self.characters_recognition_models_path = ""
        self.characters_recognition_model_file = ""
        self.license_plate_detection_model_file = ""
        self.plates_localization_model_summary = True
        self.characters_recognition_neural_model_summary = True
  
        # Training
        self.epochs_number = 2
        self.learning_rate = 0.0001  
        self.decay = 0.0001
        self.train_batch_size = 32
        self.training_algorithm = 'sgd'
        self.early_stopping = True
        self.save_best_model = True
        self.csv_logger = True
        self.log_path = ""
        self.log_file = ""
        self.train_all_layers = False
        
        # Testing
        self.characters_recognition_model_file = ''
        self.test_batch_size = 64
        self.test_on_inference = False
        self.external_validation_set = False
        self.external_validation_set_path = ''

        # Input
        self.input_path = ''

        # Output
        self.verbose = True
        self.output_path = ''
        self.log_path = '../Log'
        self.save_tiles = False
        self.charts_path = '../Output/Charts' 
        self.csv_path = '../Output/Csv'
        self.pause_time = 5
        self.plot_outputs = False
        
        # Others
        self.OS = OS
        
        # Global Constants
        # Alert Sound
        self.sound_freq = 1000                                           # Set Frequency in Hertz
        self.sound_dur = 3000                                            # Set Duration in ms, 1000 ms == 1 second
        self.times_header = ["Preprocessing Time", "Postprocessing Time", "Gpu Time", "Overall Time without Gpu", "Overall Time"]
        self.model_prefix = ''
        if conf_file_name is None:
            global config 
            
            # True for Local Mongo DB
            # False for remote instance
            db = mdb(self, mongoFlag) 
            config = db.get_config('cv_settings', self, mongoFlag)     # We read all the configuration of the backend from MongoDB   
              
        
    def read_config_file(self, codeFlag):
        
        # Read the Configuration File
        config = configparser.ConfigParser()
        
        CONFIG_REL_PATH = self.conf_file_path + '/' + self.conf_file_name
        config.read(CONFIG_REL_PATH)
        config.sections()

        # System
        self.cv_mode = config.getint('System', 'cv_mode')                                                     # 0: classify, 1: preprocess, 2: training, 3: testing
        self.gpu = config.getboolean('System', 'gpu')
        self.gpu_id = config.get('System','gpu_id')
        self.system_desc = config.get('System', 'system_desc')
        self.gpu_desc = config.get('System','gpu_desc')
        if self.gpu_desc == 'None': 
            self.gpu_desc = None

        # MongoDB
        self.connection_string = config.get('MongoDB', 'connection_string')
        self.db = config.get('MongoDB', 'mdbname')

        # Dataset
        self.license_plate_detection_data = config.getboolean('Dataset', 'license_plate_detection_data')

        if self.OS == "Linux":
            self.license_plate_detection_path = config.get('Dataset', 'license_plate_detection_path_linux')
        elif self.OS == "Windows": 
            self.license_plate_detection_path = config.get('Dataset', 'license_plate_detection_path_win')
        else:
            self.license_plate_detection_path = config.get('Dataset', 'license_plate_detection_path_linux')

        
        self.license_plate_detection_train_filename = config.get('Dataset', 'license_plate_detection_train_filename')
        self.license_plate_detection_classification_filename = config.get('Dataset', 'license_plate_detection_classification_filename')
 
        if self.OS == "Linux":
            self.characters_recognition_dataset_path = config.get('Dataset', 'characters_recognition_dataset_path_linux')
        elif self.OS == "Windows": 
            self.characters_recognition_dataset_path = config.get('Dataset', 'characters_recognition_dataset_path_win')
        else:
            self.characters_recognition_dataset_path = config.get('Dataset', 'characters_recognition_dataset_path_linux')

        self.characters_recognition_rescale = config.getboolean('Dataset', 'characters_recognition_rescale')
        self.characters_recognition_input_size = config.getint('Dataset', 'characters_recognition_input_size')
        self.mnist_benchmark = config.getboolean('Dataset', 'mnist_benchmark')

        # Preprocessing
        self.imagenet_init_weights = config.getboolean('Preprocessing', 'imagenet_init_weights')
        self.default_input_size = config.getboolean('Preprocessing', 'default_input_size')
        self.data_augmentation = config.getboolean('Preprocessing', 'data_augmentation')
        self.valid_set_perc = config.getint('Preprocessing', 'valid_set_perc') / 100                                     
        self.test_set_perc = config.getint('Preprocessing', 'test_set_perc') / 100
        self.normalize_x = config.getboolean('Preprocessing', 'normalize_x')
        self.normalize_y = config.getboolean('Preprocessing', 'normalize_y')
        self.limit = config.get('Preprocessing', 'limit')
        try: 
            self.limit = int(self.limit)

            if self.limit == 0:
                self.limit = None

        except ValueError: 
            self.limit = None
        self.shuffle = config.getboolean('Preprocessing', 'shuffle')

        # Segmentation
        self.digits_segmentation_model = config.get('Segmentation', 'digits_segmentation_model')
        self.digits_segmentation_algorithm = config.get('Segmentation', 'digits_segmentation_algorithm')
        
        # Model
        self.end_to_end = config.getboolean('Model', 'end_to_end')
        self.plates_localization_model = config.get('Model', 'plates_localization_model')
        self.characters_recognition_neural_model = config.get('Model', 'characters_recognition_neural_model')

        if self.OS == "Linux":
            self.license_plate_detection_models_path = config.get('Model', 'license_plate_detection_models_path_linux') + '/' + self.plates_localization_model
            self.characters_recognition_models_path = config.get('Model', 'characters_recognition_models_path_linux') + '/' + self.characters_recognition_neural_model
        elif self.OS == "Windows": 
            self.license_plate_detection_models_path = config.get('Model', 'license_plate_detection_models_path_win') + '/' + self.plates_localization_model
            self.characters_recognition_models_path = config.get('Model', 'characters_recognition_models_path_win') + '/' + self.characters_recognition_neural_model 
        else:
            self.license_plate_detection_models_path = config.get('Model', 'license_plate_detection_models_path_linux') + '/' + self.plates_localization_model
            self.characters_recognition_models_path = config.get('Model', 'characters_recognition_models_path_linux') + '/' + self.characters_recognition_neural_model

        self.license_plate_detection_model_file = config.get('Model', 'license_plate_detection_model_file')
        self.plates_localization_model_summary = config.getboolean('Model', 'plates_localization_model_summary')
        self.characters_recognition_neural_model_summary = config.getboolean('Model', 'characters_recognition_neural_model_summary')

        # Training
        self.epochs_number = config.getint('Training', 'epochs_number')
        self.learning_rate = config.getfloat('Training', 'learning_rate')
        self.decay = config.getfloat('Training', 'decay')
        self.train_batch_size = config.getint('Training', 'train_batch_size')
        self.training_algorithm = config.get('Training', 'training_algorithm')
        self.early_stopping = config.getboolean('Training', 'early_stopping')
        self.save_best_model = config.getboolean('Training', 'save_best_model')
        self.csv_logger = config.getboolean('Training', 'csv_logger')
        self.log_path = config.get('Training', 'log_path')
        self.log_file = config.get('Training', 'log_file')
        self.train_all_layers = config.getboolean('Training', 'train_all_layers')
        
        # Testing
        self.characters_recognition_model_file = config.get('Testing', 'characters_recognition_model_file')
        self.test_batch_size = config.getint('Testing', 'test_batch_size')
        self.test_on_inference = config.getboolean('Testing', 'test_on_inference')
        self.external_validation_set = config.getboolean('Testing', 'external_validation_set')
        self.external_validation_set_path = config.get('Testing', 'external_validation_set_path')

        # Input
        self.input_path = config.get('Input', 'input_path')

        # Output
        self.verbose = config.getboolean('Output', 'verbose')
        self.output_path = config.get('Output', 'output_path')
        self.log_path = config.get('Output', 'log_path')
        self.save_tiles = config.getboolean('Output', 'save_tiles')
        self.charts_path = config.get('Output', 'charts_path') 
        self.csv_path = config.get('Output', 'csv_path')
        self.pause_time = config.getint('Output', 'pause_time')
        self.plot_outputs = config.getboolean('Output', 'plot_outputs')
		
        # Global Constants
        self.model_prefix = self.gpu_desc.lower()+'_'+self.OS.lower()+'_'+str(self.epochs_number)+'_epochs_model_'+self.plates_localization_model.lower()+'_'
        self.train_output_header = ' '.join([x.capitalize() for x in self.model_prefix.split('_')])


        # To make the code from command line work
        if codeFlag:
            self.license_plate_detection_models_path = '../SavedModels/License_Plate_Detection' + '/' + self.plates_localization_model
            self.characters_recognition_models_path = '../SavedModels/License_Plate_Detection' + '/' + self.characters_recognition_neural_model
            self.input_path = '../Input'
            self.output_path = '../../Output'

            self.log_path = '../Log'

            self.characters_recognition_dataset_path = '../Input/dataset_characters'

        return self		

    def read_config_mongodb(self, codeFlag):
        global config

        self.random_seed = int(config['random_seed'])
        self.cv_mode = config['cv_mode']

        # Dataset
        self.license_plate_detection_data = config['license_plate_detection_data']

        if self.OS == "Linux":
            self.license_plate_detection_path = config['license_plate_detection_path_linux']
        elif self.OS == "Windows": 
            self.license_plate_detection_path = config['license_plate_detection_path_win']
        else:
            self.license_plate_detection_path = config['license_plate_detection_path_linux']

        
        self.license_plate_detection_train_filename = config['license_plate_detection_train_filename']
        self.license_plate_detection_classification_filename = config['license_plate_detection_classification_filename']
 
        if self.OS == "Linux":
            self.characters_recognition_dataset_path = config['characters_recognition_dataset_path_linux']
        elif self.OS == "Windows": 
            self.characters_recognition_dataset_path = config['characters_recognition_dataset_path_win']
        else:
            self.characters_recognition_dataset_path = config['characters_recognition_dataset_path_linux']

        self.characters_recognition_rescale = config['characters_recognition_rescale']
        self.characters_recognition_input_size = config['characters_recognition_input_size']
        self.mnist_benchmark = config['mnist_benchmark']
        
        # Preprocessing
        self.imagenet_init_weights = config['imagenet_init_weights']
        self.default_input_size = config['default_input_size']
        self.data_augmentation = config['data_augmentation']

        self.valid_set_perc = config['valid_set_perc'] / 100                                        # Validation set percentage with respect to the Training Set
        self.test_set_perc = config['test_set_perc'] / 100                                          # Test set percentage with respect to the entire Data Set
        self.normalize_x = config['normalize_x']
        self.normalize_y = config['normalize_y']
        self.limit = config['limit']
        
        try: 
            self.limit = int(self.limit)

            if self.limit == 0:
                self.limit = None    

        except ValueError: 
            self.limit = None
        
        self.shuffle = config['shuffle']

        # Model 
        self.plates_localization_model = config['plates_localization_model']
        self.characters_recognition_neural_model = config['characters_recognition_neural_model']

        if self.OS == "Linux":
            self.license_plate_detection_models_path = config['license_plate_detection_models_path_linux'] + '/' + self.plates_localization_model
            self.characters_recognition_models_path = config['characters_recognition_models_path_linux'] + '/' + self.characters_recognition_neural_model
        elif self.OS == "Windows": 
            self.license_plate_detection_models_path = config['license_plate_detection_models_path_win'] + '/' + self.plates_localization_model
            self.characters_recognition_models_path = config['characters_recognition_models_path_win'] + '/' + self.characters_recognition_neural_model
        else:
            self.license_plate_detection_models_path = config['license_plate_detection_models_path_linux'] + '/' + self.plates_localization_model
            self.characters_recognition_models_path = config['characters_recognition_models_path_linux'] + '/' + self.characters_recognition_neural_model
        
        self.license_plate_detection_model_file = config['license_plate_detection_model_file']
        self.plates_localization_model_summary = config['plates_localization_model_summary']
        
        #@TODO: Need to double check this
        self.characters_recognition_model_file = config['characters_recognition_neural_model'] + "_30.json"
        self.plates_localization_model_summary = config['plates_localization_model_summary']
        self.characters_recognition_neural_model_summary = config['characters_recognition_neural_model_summary']

        # Training        
        self.epochs_number = config['epochs_number']
        self.learning_rate = config['learning_rate']
        self.decay = config['decay']
        self.train_batch_size = config['train_batch_size']
        self.training_algorithm = config['training_algorithm']
        self.early_stopping = config['early_stopping']
        self.save_best_model = config['save_best_model']
        self.csv_logger = config['csv_logger']
        self.log_path = config['log_path']
        self.log_file = config['log_file']

        self.train_all_layers = config['train_all_layers']
       
        # Testing
        self.test_batch_size = config['test_batch_size']
        self.test_on_inference = config['test_on_inference']

        # Input
        self.input_path = config['input_path']

        # Output
        self.output_path = config['output_path']
        self.log_path = config['log_path']
        self.save_tiles = config['save_tiles']
        self.charts_path = config['charts_path'] 
        self.csv_path = config['csv_path']
        self.pause_time = config['pause_time']
        self.plot_outputs = config['plot_outputs']

        # To make the code from command line work
        if codeFlag:
            self.license_plate_detection_models_path = '../SavedModels/License_Plate_Detection' + '/' + self.plates_localization_model 
            self.characters_recognition_models_path = '../SavedModels/License_Plate_Detection' + '/' + self.characters_recognition_neural_model
            self.input_path = '../Input'
            self.output_path = '../Output'

            self.log_path = '../Log'

            self.characters_recognition_dataset_path = '../Input/dataset_characters'
            
        return self