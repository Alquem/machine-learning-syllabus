#!/bin/bash
# file: loop_classification_run.sh
until python computer_vision_run.py -c computer_vision_mobilenet_5.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_mobilenet_10.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_mobilenet_20.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_mobilenet_30.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_xception_5.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_xception_10.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_xception_20.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_xception_30.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_xception_100.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_inception_5.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_inception_10.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_inception_20.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_inception_30.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_resnet_5.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_resnet_10.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_resnet_20.ini -m 1 2>/dev/null
do
  sleep 0.1
done
until python computer_vision_run.py -c computer_vision_resnet_30.ini -m 1 2>/dev/null
do
  sleep 0.1
done
<<'###'
###
