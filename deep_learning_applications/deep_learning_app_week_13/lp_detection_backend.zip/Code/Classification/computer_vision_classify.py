'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

from Models.wpodnet import WPodNet
from Models.advanced_cv_model import AdvancedCVModel
from Preprocessing.preprocessing import Preprocessing
from Segmentation.plate_segmentation import Segmentation
from View.view import View
import numpy as np
import pandas as pd
from imutils import paths
import os
import shutil
import pdb
from pathlib import Path
import tensorflow
import timeit

if tensorflow.__version__ > '2.0.0':
    from tensorflow.keras import backend as K
    from tensorflow.keras.optimizers import Adam, SGD
else:
    from keras import backend as K
    from keras.optimizers import Adam, SGD

from os.path import splitext, basename

class ComputerVisionClassify(object):
    def __init__(self, params, mongodb):
        self.__params = params
        self.__mongodb = mongodb

    def classify(self, image_path):
        # load data
        classify_start_time = timeit.default_timer()
        
        preproc = Preprocessing(self.__params)    

        if self.__params.external_validation_set is True:
            if not os.path.exists(self.__params.output_path+"/"+"Validation_Set_Vehicle_Pipeline"):
                os.makedirs(self.__params.output_path+"/"+"Validation_Set_Vehicle_Pipeline")
            else:
                shutil.rmtree(self.__params.output_path+"/"+"Validation_Set_Vehicle_Pipeline")
                os.makedirs(self.__params.output_path+"/"+"Validation_Set_Vehicle_Pipeline")
        '''
        if self.__mongodb == False: 
            dataset = preproc.load_license_plate_detection_data_from_local_disk(self.__params)
        '''
        
        vd_results = {
            'vehicle_number': '',
            'license_plate': '',
            'segmented_plate': '',
            'digit_contour': '',
            'segmented_letters': ''
        }

        if self.__params.plates_localization_model == "wpodnet":  
            deepnetwork_pl = WPodNet.load_model(self.__params.license_plate_detection_models_path + '/' + self.__params.license_plate_detection_model_file, self.__params.plates_localization_model_summary, self.__params.verbose)
            
            # For one single image detection purposes
            if image_path == '':
                flag_64 = False
                # Replace the image path here if you running via code
                #test_image = '../Input/ej567pl_daytime_clear_3.jpg' 
                #test_image = '../Input/ek945nw_daytime_clear_6.jpg'
                test_image = '../Input/posteriore02262021143931.453.jpg'
            else:
                flag_64 = True
                
                # Called from interface or API
                test_image = image_path
            
            # For single car external validation purposes
            vehicles = []
            if self.__params.external_validation_set is not True:
                vehicle = Preprocessing.load_license_plate_detection_data_from_local_disk(test_image, True, self.__params.verbose)
                vehicles.append([vehicle, '', '', '','', test_image])
            else:
                if self.__params.verbose == True:
                    print("Loading Vehicle Validation Set...")
                # grab the path of all images 
                image_paths = sorted(list(paths.list_images(self.__params.external_validation_set_path)))
                for ip in image_paths:
                    name = ip.split(os.path.sep)[1]
                    
                    if self.__params.OS == "Windows":
                        arr_name_split = ip.split(os.path.sep)[1].split('_')
                    elif self.__params.OS == "Linux":
                        arr_name_split = ip.split(os.path.sep)[3].split('_')
                        
                    
                    label = arr_name_split[0]
                    #pdb.set_trace()
                    timeband = arr_name_split[1]
                    weather_conditions = arr_name_split[2]
                    
                    vehicle = Preprocessing.load_license_plate_detection_data_from_local_disk(ip)
                    vehicles.append([vehicle, name, label, timeband, weather_conditions, ip])

            # Determines the number of vehicles to process
            if self.__params.external_validation_set is True: 
                total_vehicles = len(vehicles)
            else: 
                total_vehicles = 1

            license_plates = []
            for v in range(total_vehicles): 
                if self.__params.external_validation_set is True:
                    pipeline_save_dir = self.__params.output_path+"/"+"Validation_Set_Vehicle_Pipeline"+"/"+ vehicles[v][1].split('.')[0]
                    if not os.path.exists(pipeline_save_dir):
                        os.makedirs(pipeline_save_dir)
                else:
                    pipeline_save_dir = self.__params.output_path
                    
                license_plate, cor = WPodNet.get_plate(vehicles[v][0], deepnetwork_pl, vehicles[v][5])
                
                try:
                    if self.__params.verbose == True:
                        print("Detect %i plate(s) in"%len(license_plate),splitext(basename(vehicles[v][5]))[0])
                        print("Coordinate of plate(s) in image: \n", cor)

                    vd_results['license_plate'] = View.save_and_plot_vehicle_and_plate(vehicle, license_plate, pipeline_save_dir, self.__params.plot_outputs, flag_64)
                except:
                    K.clear_session()

                license_plates.append([license_plate, cor, pipeline_save_dir])
        

        if self.__params.test_on_inference == True:
            preproc = Preprocessing(self.__params)    
            train_set_x, train_set_y, val_set_x, val_set_y, test_set_x, test_set_y, n_channels, n_classes = preproc.load_characters_dataset_from_local_disk(self.__params)
            opt = Adam(lr=self.__params.learning_rate, decay = self.__params.learning_rate / self.__params.epochs_number)
            deepnetwork_ocr.compile(optimizer = opt, loss='categorical_crossentropy', metrics=['accuracy'])
            score = deepnetwork_ocr.evaluate(test_set_x, test_set_y, batch_size = self.__params.test_batch_size)
            print(score)
        
        labels_truth_and_predicted = []
        for lp in license_plates: 
            # Executing remaining steps only if the license plate is detected 
            if lp[0] != None:
                # Model compiling
                deepnetwork_ocr, labels = AdvancedCVModel.load_model(self.__params.characters_recognition_models_path + '/' + self.__params.characters_recognition_model_file, 
                                                                    self.__params.characters_recognition_models_path, 
                                                                    self.__params.characters_recognition_neural_model_summary,
                                                                    self.__params.characters_recognition_neural_model,
                                                                    self.__params.verbose)

                # Segment the charactors
                if self.__params.digits_segmentation_model == 'opencv':
                    crop_characters, vd_results['segmented_plate'], vd_results['digit_contour'], vd_results['segmented_letters']  = Segmentation.plate_segmentation(lp[0], self.__params.digits_segmentation_algorithm, lp[2], self.__params.plot_outputs, flag_64, self.__params.verbose)

                vd_results['vehicle_number'] = AdvancedCVModel.predict_plate(crop_characters, deepnetwork_ocr, labels)
                
                if self.__params.verbose == True:
                    print("License Plate Vehicle Number:", vd_results['vehicle_number'])
                            
            scores = '%s, %s, %s' % (self.__params.characters_recognition_neural_model, str(self.__params.epochs_number), vd_results['vehicle_number'])
            with open(self.__params.output_path + '/' "classification_results.csv", "ab") as f:
                np.savetxt(f, [scores], delimiter = ",", fmt = "%s")

            K.clear_session()
            labels_truth_and_predicted.append(vd_results['vehicle_number'].lower())
        
        if self.__params.external_validation_set is True:
            names = np.asarray(vehicles)[:,1].reshape(-1,1)
            ground_truth = np.asarray(vehicles)[:,2].reshape(-1,1)
            predicted = np.asarray(labels_truth_and_predicted).reshape(-1,1)
            check = 1*(ground_truth == predicted)
            output = np.hstack((names, ground_truth, predicted, check))
            external_accuracy_single_car = round(check.sum()/len(check), 3)
            print("On Validation Set there are: ", check.sum(), "/", len(check))
            print("External accuracy on Validation Set:", external_accuracy_single_car)
            with open(self.__params.output_path + '/' "external_validation_"+
                      self.__params.plates_localization_model.lower()+'_'+
                      self.__params.digits_segmentation_model.lower()+'_'+
                      self.__params.characters_recognition_neural_model.lower()+'_'+".csv", "wb") as f:
                np.savetxt(f, output, delimiter = ",", header = "Multi Stage Model: "+
                                                                self.__params.plates_localization_model.upper()+'-'+
                                                                self.__params.digits_segmentation_model.upper()+'-'+
                                                                self.__params.characters_recognition_neural_model.upper()+' '
                                                                "\nExternal Accuracy: "+str(external_accuracy_single_car)+
                                                                "\nNumber of correct license plates: "+ str(check.sum()) + "/" + str(len(check))+
                                                                "\n\nFile Name, Ground Truth, Predicted, Check", fmt = "%s")

        
        print ('\n\nClassification time: %.2f minutes\n' % ((timeit.default_timer() - classify_start_time) / 60.))
        
        return vd_results
