'''
Created on 22/04/2022
Modified on 22/04/2022

@author: Francesco Pugliese
'''

# Keras Imports
import tensorflow
if tensorflow.__version__ > '2.0.0':
    from tensorflow.keras.callbacks import CSVLogger, ModelCheckpoint, EarlyStopping
    from tensorflow.keras.preprocessing.image import ImageDataGenerator
    from tensorflow.keras.optimizers import Adam, SGD
    from tensorflow.keras.layers import AveragePooling2D
    from tensorflow.keras.layers import Dropout
    from tensorflow.keras.layers import Flatten
    from tensorflow.keras.layers import Dense
    from tensorflow.keras.layers import Input
    from tensorflow.keras.models import Model
else:
    from keras.callbacks import CSVLogger, ModelCheckpoint, EarlyStopping
    from keras.preprocessing.image import ImageDataGenerator
    from keras.optimizers import Adam, SGD
    from keras.layers import AveragePooling2D
    from keras.layers import Dropout
    from keras.layers import Flatten
    from keras.layers import Dense
    from keras.layers import Input
    from keras.models import Model

# Program Imports
from Models.advanced_cv_model import AdvancedCVModel
from Preprocessing.preprocessing import Preprocessing

# Other Imports
import pdb
import pandas as pd
import numpy as np

class ComputerVisionTraining(object):
    def __init__(self, params, mongodb):
        self.__params = params
        self.__mongodb = mongodb
    
    def train(self):
        print("Training mode is starting")
        ###############################################################

        default_callbacks = []
        preproc = Preprocessing(self.__params)    
        #if self.__mongodb == False: 
        train_set_x, train_set_y, val_set_x, val_set_y, test_set_x, test_set_y, n_channels, n_classes = preproc.load_characters_dataset_from_local_disk(self.__params)
        
        n_train_batches = len(train_set_x) // self.__params.train_batch_size                                                                                             
        n_test_batches = len(test_set_x) // self.__params.test_batch_size                                                                                              
        print('\nTrain set size: ', (train_set_x.shape[0], train_set_x.shape[1]))
        print('Test set size: ', (test_set_x.shape[0], test_set_x.shape[1]))
        print('Train set number of batches: ', n_train_batches)
        print('Test set number of batches: ', n_test_batches)
        print('Number of classes: ', n_classes)
        print('Number of channels: ', n_channels)
        print('\n')
        
        # Data Augumentation
        if self.__params.data_augmentation == True: 
            image_gen = ImageDataGenerator(rotation_range=10,
                                           width_shift_range=0.1,
                                           height_shift_range=0.1,
                                           shear_range=0.1,
                                           zoom_range=0.1,
                                           fill_mode="nearest"
                                           )

        deep_model = AdvancedCVModel.build(self.__params.characters_recognition_neural_model, 
                                      self.__params.characters_recognition_input_size, 
                                      self.__params.default_input_size,
                                      n_channels,
                                      n_classes,
                                      self.__params.imagenet_init_weights, 
                                      self.__params.train_all_layers,
                                      self.__params.characters_recognition_neural_model_summary)
        
        opt = Adam(lr=self.__params.learning_rate, decay = self.__params.learning_rate / self.__params.epochs_number)
        #opt = SGD(lr=self.__params.learning_rate, decay = self.__params.decay)
        
        deep_model.compile(optimizer = opt, loss='categorical_crossentropy', metrics=['accuracy'])
        
        if self.__params.csv_logger == True:
            csv_logger = CSVLogger(self.__params.log_path + '/' + self.__params.characters_recognition_neural_model + '_' + str(self.__params.epochs_number) + '_' + self.__params.log_file)
            default_callbacks = default_callbacks + [csv_logger]

        if self.__params.OS == "Linux":
            monitor_variable = 'val_acc'
        elif self.__params.OS == "Windows": 
            monitor_variable = 'val_accuracy'
        else: 
            monitor_variable = 'val_acc'

        if self.__params.save_best_model == True: 
            checkPoint = ModelCheckpoint(self.__params.characters_recognition_models_path+"/"+self.__params.characters_recognition_neural_model + '_' + str(self.__params.epochs_number)+".h5", save_weights_only=True, monitor=monitor_variable, verbose=1, save_best_only=True, mode='max')
            default_callbacks = default_callbacks+[checkPoint]

        if self.__params.early_stopping == True:
            earlyStopping=EarlyStopping(monitor='val_loss', delta = 0.01, patience=5, verbose=0, mode='min') 
            default_callbacks = default_callbacks+[earlyStopping]
            
        # Train the model, iterating on the data in batches
        if self.__params.data_augmentation == False: 
            history = deep_model.fit(train_set_x, train_set_y, batch_size = self.__params.train_batch_size, epochs = self.__params.epochs_number, validation_data = (val_set_x, val_set_y), callbacks = default_callbacks, verbose = 2)
        else:
            steps_per_epoch = len(train_set_x) / self.__params.train_batch_size
            history = deep_model.fit_generator(image_gen.flow(train_set_x, train_set_y, batch_size = self.__params.train_batch_size), steps_per_epoch = steps_per_epoch, epochs = self.__params.epochs_number, validation_data = (val_set_x, val_set_y), callbacks = default_callbacks, verbose = 2)

        # save model architectur as json file
        model_json = deep_model.to_json()
        with open(self.__params.characters_recognition_models_path+"/"+self.__params.characters_recognition_neural_model + '_' + str(self.__params.epochs_number)+".json", "w") as json_file:
          json_file.write(model_json)

        history_csv = pd.read_csv(self.__params.log_path + '/' + self.__params.characters_recognition_neural_model + '_' + str(self.__params.epochs_number) + '_' + self.__params.log_file)

        score = deep_model.evaluate(test_set_x, test_set_y, batch_size = self.__params.test_batch_size)
        print(score)
        # Saving test set accuracy and loss
        scores = '%f, %f' % (round(score[0],5), round(score[1],5))
        #pdb.set_trace()
        with open(self.__params.log_path + '/' + self.__params.characters_recognition_neural_model + '_' + str(self.__params.epochs_number) + '_' + self.__params.log_file, "ab") as f:
            np.savetxt(f, [scores], delimiter = ",", fmt = "%s")

        K.clear_session()
        
        return [history_csv]