class AdvancedCVModel:
    
    @staticmethod
    def build(width, height, depth, classes, summary, weightsPath=None):
    
        if neural_model == 'Xception':
            model = Xception(weights = weights, include_top=False, input_shape = inputShape)
        elif neural_model == 'VGG16': 
            model = VGG16(weights = weights, include_top=False, input_shape = inputShape)
        elif neural_model == 'VGG19':
            model = VGG19(weights = weights, include_top=False, input_shape = inputShape)
        elif neural_model == 'ResNet50':
            model = ResNet50(weights = weights, include_top=False, input_shape = inputShape)
        elif neural_model == 'MobileNet':
            model = MobileNet(weights = weights, include_top=False, input_shape = inputShape)
        elif neural_model == 'InceptionResNetV2':
            model = InceptionResNetV2(weights = weights, include_top=False, input_shape = inputShape)
        elif neural_model == 'NASNetLarge':
            model = NASNetLarge(weights = weights, input_shape = inputShape)

        # return the constructed network architecture
        return model